package com.example.tipcalculator;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/*
Handles the tip calculator page. This page allows the user to input their cashout. This page will allow them to save their results.
This page will be configured through the settings page

Created by Freddie Banfield
2021-08-02
 */
public class AddTipFragment extends Fragment {

    private double input1Text, input2Text, input3Text, input4Text, moneyOwed, input1Result, input2Result, input3Result,
            input4Result, owedTips, cash, input1Percentage, input2Percentage, input3Percentage, input4Percentage;
    private static final String fileName = "saved_settings.txt";
    private static final String defaultSettings = "2,Kitchen Sales,4.5,Bar Sales,4.0, ,0, ,0";

    private Button calcBTN;
    private TextView input1TB, input2TB, input3TB, input4TB, owedTB, cashTB, perc1LBL, perc2LBL, perc3LBL, perc4LBL;

    private int boxMode;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //Checks if its first time opening app. If it is, write a new file with default settings.
        SharedPreferences prefs = this.getActivity().getSharedPreferences("prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        boolean firstStart = prefs.getBoolean("firstStart", true);

        if (firstStart) {
            writeToFile(defaultSettings);
            editor.putBoolean("firstStart", false);
            editor.apply();
        }

        //Reads settings and outputs to String Array
        String[] individualSettings = readSettings(); //Loads in the Saved settings

        View view = null;
        //Loads Graphics
        if(boxMode == 1)
            view = inflater.inflate(R.layout.fragment_addtip_1, container, false);
        else if (boxMode == 2)
            view = inflater.inflate(R.layout.fragment_addtip_2, container, false);
        else if (boxMode == 3)
            view = inflater.inflate(R.layout.fragment_addtip_3, container, false);
        else
            view = inflater.inflate(R.layout.fragment_addtip_4, container, false);


        //Loads settings into Graphics
        loadSettings(individualSettings, view);

        //When Calculator Button is Clicked
        calcBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    //If text boxes are left blank
                    switch (boxMode) {
                        case 4:
                            if (input4TB.getText().toString().length() < 1) input4TB.setText("0");
                        case 3:
                            if (input3TB.getText().toString().length() < 1) input3TB.setText("0");
                        case 2:
                            if (input2TB.getText().toString().length() < 1) input2TB.setText("0");
                        case 1:
                            if (input1TB.getText().toString().length() < 1) input1TB.setText("0");
                            break;
                    }
                    if (owedTB.getText().toString().length() < 1){
                        owedTB.setText("0");
                    }
                    if (cashTB.getText().toString().length() < 1){
                        cashTB.setText("0");
                    }


                    //creates pop up window
                    Intent intent = new Intent(getActivity(), ResultsPage.class);
                    owedTips = 0; //Resets result
                    //Calculates visible textbox results
                    switch (boxMode){
                        case 4:
                            //Gets input4 sales, multiplies percentage, outputs result
                            input4Text = Double.parseDouble(input4TB.getText().toString());
                            input4Result = input4Text * (0.01 * input4Percentage);
                            intent.putExtra("input4Results",String.format("%.2f", input4Result));
                            owedTips += input4Result;
                        case 3:
                            //Gets input3 sales, multiplies percentage, outputs result
                            input3Text = Double.parseDouble(input3TB.getText().toString());
                            input3Result = input3Text * (0.01 * input3Percentage);
                            intent.putExtra("input3Results",String.format("%.2f", input3Result));
                            owedTips += input3Result;
                        case 2:
                            //Gets input2 sales, multiplies percentage, outputs result
                            input2Text = Double.parseDouble(input2TB.getText().toString());
                            input2Result = input2Text * (0.01 * input2Percentage);
                            intent.putExtra("input2Results",String.format("%.2f", input2Result));
                            owedTips += input2Result;
                        case 1:
                            //Gets input1 sales, multiplies percentage, outputs result
                            input1Text = Double.parseDouble(input1TB.getText().toString());
                            input1Result = (input1Text * (0.01 * input1Percentage));
                            intent.putExtra("input1Results",String.format("%.2f", input1Result));
                            owedTips += input1Result;
                            break;
                    }
                    //Gets money owed, adds both kitchenTips and barTips to owed amount, outputs result
                    moneyOwed = Double.parseDouble(owedTB.getText().toString());
                    owedTips += moneyOwed;
                    //calculates profit by adding cash received
                    cash = Double.parseDouble(cashTB.getText().toString());

                    intent.putExtra("restaurant",String.format("%.2f", owedTips));
                    intent.putExtra("profit",String.format("%.2f", ((-cash + owedTips)* -1)));
                    intent.putExtra("boxMode",boxMode);
                    startActivity(intent);

                }
                catch(Exception e){
                    System.out.print("ERROR: Issue with calculation");

                    switch (boxMode){
                        case 4:
                            input4TB.setText("");
                        case 3:
                            input3TB.setText("");
                        case 2:
                            input2TB.setText("");
                        case 1:
                            input1TB.setText("");
                            break;
                    }
                    owedTB.setText("");
                    cashTB.setText("");

                    /*kitchenLBL.setText("Kitchen Tips");
                    barLBL.setText("Bar Tips");
                    owedLBL.setText("Tips Owed");
                    profitLBL.setText("Profit");*/


                }

            }

        });
        return view;
    }




    /**
     * Reads Settings from file and outputs a String Array
     * Also sets BoxMode
     *
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private String[] readSettings(){
        //Reads settings from file to setup the page text boxes
        String settings = readFromFile();
        String[] individualSettings = settings.split(",");

        System.out.println(settings);

        boxMode = Integer.parseInt(individualSettings[0]); //Sets how many boxes to saved settings

        return individualSettings;
    }


    /**
     * Takes Settings (as String Array) and adjusts graphics accordingly
     * The graphics are configured relative to the boxmode
     *      *
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void loadSettings(String[] individualSettings, View view){
        calcBTN = view.findViewById(R.id.calcBTN);
        owedTB = view.findViewById(R.id.owedTB);
        cashTB = view.findViewById(R.id.cashTB);
        switch(boxMode) {
            case 4:
                input4TB = view.findViewById(R.id.input4TB);
                perc4LBL = view.findViewById(R.id.perc4LBL);
                input4TB.setHint(individualSettings[7]); //Sets barTB Text to saved settings
                input4Percentage = Double.parseDouble(individualSettings[8]); //Sets 1st box percentage
                perc4LBL.setText("" + input4Percentage + "%");
            case 3:
                input3TB = view.findViewById(R.id.input3TB);
                perc3LBL = view.findViewById(R.id.perc3LBL);
                input3TB.setHint(individualSettings[5]); //Sets barTB Text to saved settings
                input3Percentage = Double.parseDouble(individualSettings[6]); //Sets 1st box percentage
                perc3LBL.setText("" + input3Percentage + "%");
            case 2:
                input2TB = view.findViewById(R.id.input2TB);
                perc2LBL = view.findViewById(R.id.perc2LBL);
                input2TB.setHint(individualSettings[3]); //Sets barTB Text to saved settings
                input2Percentage = Double.parseDouble(individualSettings[4]); //Sets 1st box percentage
                perc2LBL.setText("" + input2Percentage + "%");
            case 1:
                input1TB = view.findViewById(R.id.input1TB);
                perc1LBL = view.findViewById(R.id.perc1LBL);
                input1TB.setHint(individualSettings[1]); //Sets 1st Text to saved settings
                input1Percentage = Double.parseDouble(individualSettings[2]); //Sets 1st box percentage
                perc1LBL.setText("" + input1Percentage + "%");
                break;
        }
    }

    /**
     * Reads from file
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private String readFromFile(){

        FileInputStream fis = null;
        try {
            fis = getContext().openFileInput(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(inputStreamReader)) {
            String line = reader.readLine();
            while (line != null) {
                stringBuilder.append(line).append('\n');
                line = reader.readLine();
            }
        } catch (IOException e) {
            // Error occurred when opening raw file for reading.
        } finally {
            String contents = stringBuilder.toString();
            return contents;
        }
    }

    /**
     * Writes to file
     * @param text
     */
    private void writeToFile(String text) {
        FileOutputStream fos = null;
        Toast.makeText(getContext(), text,
                Toast.LENGTH_LONG).show();
        try {
            fos = getActivity().openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(text.getBytes());


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
