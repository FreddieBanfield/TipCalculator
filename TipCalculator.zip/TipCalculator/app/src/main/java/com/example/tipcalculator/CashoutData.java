package com.example.tipcalculator;

import java.util.Date;

public class CashoutData {

    private int id;
    private String date;
    private double owedTips;
    private double profit;

    // Constructor
    public CashoutData(int id, String date, double owedTips, double profit) {
        this.id = id;
        this.date = date;
        this.owedTips = owedTips;
        this.profit = profit;
    }

    public CashoutData() {
    }

    // To string method

    @Override
    public String toString() {
        return
                "ID: " + id +
                ", \nDate: " + date +
                ", \nOwed Tips: " + owedTips +
                ", \nProfit: " + profit;
    }


    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getOwedTips() {
        return owedTips;
    }

    public void setOwedTips(double owedTips) {
        this.owedTips = owedTips;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }
}
