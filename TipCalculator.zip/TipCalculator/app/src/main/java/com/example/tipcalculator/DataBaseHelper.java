package com.example.tipcalculator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String CASHOUT_TABLE = "CASHOUT_TABLE";
    public static final String COLUMN_DATE = "DATE";
    public static final String COLUMN_OWED_TIPS = "OWED_TIPS";
    public static final String COLUMN_PROFIT = "PROFIT";
    public static final String COLUMN_ID = "ID";

    public DataBaseHelper(@Nullable Context context) {
        super(context, "cashouts.db", null, 1);
    }

    //First time the data base is accessed. Code relates to creating a Database
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + CASHOUT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_DATE + " TEXT, " + COLUMN_OWED_TIPS + " REAL, " + COLUMN_PROFIT + " REAL)";

        db.execSQL(createTableStatement);
    }

    //Data base version number changes. It prevents previous users apps from breaking when you change the database design.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(CashoutData cashoutData){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_DATE, cashoutData.getDate());
        cv.put(COLUMN_OWED_TIPS, cashoutData.getOwedTips());
        cv.put(COLUMN_PROFIT, cashoutData.getProfit());

        long insert = db.insert(CASHOUT_TABLE, null, cv);

        if (insert == -1){
            return false;
        }else {
            return true;
        }
    }

    public boolean deleteOne(CashoutData cashoutData){
        // find cashout in database. if it found, delete it and return true
        // if it is not found, return false

        SQLiteDatabase db = this.getReadableDatabase();
        String queryString = "DELETE FROM " + CASHOUT_TABLE + " WHERE " + COLUMN_ID + " = " + cashoutData.getId();

        Cursor cursor = db.rawQuery(queryString, null);
        if(cursor.moveToFirst()){
            return true;
        }else{
            return false;
        }
    }


    public List<CashoutData> getEveryDay(){
        List<CashoutData> returnList = new ArrayList<>();

        // get data from the database

        String queryString = "SELECT * FROM " + CASHOUT_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            // loop through the cursor (the results) and create a new cashout object. Put them into the return list.
            do{
                int cashoutID = cursor.getInt(0);
                String cashoutDate = cursor.getString (1);
                double cashoutOwedTips = cursor.getDouble(2);
                double cashoutProfit = cursor.getDouble(3);

                CashoutData newCashout = new CashoutData(cashoutID,cashoutDate,cashoutOwedTips,cashoutProfit);
                returnList.add(newCashout);
            }while (cursor.moveToNext());

        }else{
            // falure. do not add anything to the list
        }
        // close both the cursor and the db when done
        cursor.close();
        db.close();
        return returnList;
    }
}
