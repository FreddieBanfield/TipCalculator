package com.example.tipcalculator;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/*
ReadWrite is a java class that retrieves and saves data to a file
 */
public class ReadWrite{
 //"saved_settings.txt" or "tip_data.txt"

    private Context context;
    private Activity activity;

    /**
     * Creates ReadWrite Object
     */
    public ReadWrite(Activity act, Context ct) {
        context = ct;
        activity = act;
    }

    /**
     * Writes to file
     * @param text
     * @param fileName
     */
    public void writeToFile(String text, String fileName) {
        FileOutputStream fos = null;
        try {
            fos = activity.openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(text.getBytes());

            Toast.makeText(context, "Saved to " + context.getFilesDir() + "/" + fileName,
                    Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Reads from file
     * @param fileName
     * @return
     */
    public String readFromFile(String fileName) {
        String text = new String();

        FileInputStream fis = null;

        try {
            fis = context.openFileInput(fileName);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();

            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return text;
    }


}
