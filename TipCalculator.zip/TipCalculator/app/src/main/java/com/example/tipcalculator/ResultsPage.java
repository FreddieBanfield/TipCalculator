package com.example.tipcalculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ResultsPage extends Activity {

    private String input1Results, input2Results, input3Results, input4Results, owedRestaurant, profit, dateString;


    @RequiresApi(api = Build.VERSION_CODES.O)
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        int boxMode = intent.getIntExtra("boxMode", 3);
        switch (boxMode){
            case 4:
                setContentView(R.layout.popup_addtip_results_4);
                break;
            case 3:
                setContentView(R.layout.popup_addtip_results_3);
                break;
            case 2:
                setContentView(R.layout.popup_addtip_results_2);
                break;
            case 1:
                setContentView(R.layout.popup_addtip_results_1);
                break;
        }




        //Window Settings
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int) (width*0.9),(int)(height * 0.9));
        getWindow().setElevation(200);

        //Configure Labels
        final TextView input1LBL = findViewById(R.id.result1LBL);
        final TextView input2LBL = findViewById(R.id.result2LBL);
        final TextView input3LBL = findViewById(R.id.result3LBL);
        final TextView input4LBL = findViewById(R.id.result4LBL);
        final TextView owedLBL = findViewById(R.id.owedLBL);
        final TextView profitLBL = findViewById(R.id.profitLBL);
        final TextView dateLBL = findViewById(R.id.dateLBL);

        //Initializing the date formatter
        Date date = new Date();
        String pattern = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        dateString = simpleDateFormat.format(date);

        switch (boxMode){
            case 4:
                input4Results = intent.getStringExtra("input4Results");
                input4LBL.setText(input4Results);
            case 3:
                input3Results = intent.getStringExtra("input3Results");
                input3LBL.setText(input3Results);
            case 2:
                input2Results = intent.getStringExtra("input2Results");
                input2LBL.setText(input2Results);
            case 1:
                input1Results = intent.getStringExtra("input1Results");
                input1LBL.setText(input1Results);
                break;
        }
        owedRestaurant = intent.getStringExtra("restaurant");
        profit = intent.getStringExtra("profit");

        owedLBL.setText(owedRestaurant);
        profitLBL.setText(profit);
        dateLBL.setText(dateString);


        // Save Button

        final Button saveBtn = findViewById(R.id.saveBtn);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CashoutData cashoutData = null;
                try {
                    cashoutData = new CashoutData(-1, dateString, Double.parseDouble(owedRestaurant), Double.parseDouble(profit));
                    Toast.makeText(ResultsPage.this, "Saved Cashout :" + cashoutData.toString(), Toast.LENGTH_SHORT).show();
                }catch(Exception e){
                    Toast.makeText(ResultsPage.this, "Error Saving Data", Toast.LENGTH_SHORT).show();
                    cashoutData = new CashoutData(-1, "error", 0.0, 0.0);
                }
                DataBaseHelper dataBaseHelper = new DataBaseHelper(ResultsPage.this);

                boolean success = dataBaseHelper.addOne(cashoutData);

                Toast.makeText(ResultsPage.this, "Success=" + success, Toast.LENGTH_SHORT).show();
            }
        });

    }
}
