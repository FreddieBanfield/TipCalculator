package com.example.tipcalculator;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class SettingsFragment extends Fragment {

    private int boxMode = 3;

    private static final String fileName = "saved_settings.txt";

    private RadioButton oneRB;
    private RadioButton twoRB;
    private RadioButton threeRB;
    private RadioButton fourRB;

    private TextView desc1TB;
    private TextView desc2TB;
    private TextView desc3TB;
    private TextView desc4TB;

    private TextView perc1TB;
    private TextView perc2TB;
    private TextView perc3TB;
    private TextView perc4TB;

    private Button saveBTN;
    private RadioGroup radioGroup;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Nullable
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        //Gets Items from view
        oneRB = view.findViewById(R.id.oneRB);
        twoRB = view.findViewById(R.id.twoRB);
        threeRB = view.findViewById(R.id.threeRB);
        fourRB = view.findViewById(R.id.fourRB);

        desc1TB = view.findViewById(R.id.desc1TB);
        desc2TB = view.findViewById(R.id.desc2TB);
        desc3TB = view.findViewById(R.id.desc3TB);
        desc4TB = view.findViewById(R.id.desc4TB);

        perc1TB = view.findViewById(R.id.percent1TB);
        perc2TB = view.findViewById(R.id.percent2TB);
        perc3TB = view.findViewById(R.id.percent3TB);
        perc4TB = view.findViewById(R.id.percent4TB);

        saveBTN = view.findViewById(R.id.saveBTN);

        radioGroup = view.findViewById(R.id.radioGroup);

        //Enables or disables text boxes depending on layout
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId==R.id.oneRB){
                    desc1TB.setEnabled(true);
                    desc2TB.setEnabled(false);
                    desc3TB.setEnabled(false);
                    desc4TB.setEnabled(false);

                    perc1TB.setEnabled(true);
                    perc2TB.setEnabled(false);
                    perc3TB.setEnabled(false);
                    perc4TB.setEnabled(false);
                }
                if(checkedId==R.id.twoRB){
                    desc1TB.setEnabled(true);
                    desc2TB.setEnabled(true);
                    desc3TB.setEnabled(false);
                    desc4TB.setEnabled(false);

                    perc1TB.setEnabled(true);
                    perc2TB.setEnabled(true);
                    perc3TB.setEnabled(false);
                    perc4TB.setEnabled(false);
                }
                if(checkedId==R.id.threeRB){
                    desc1TB.setEnabled(true);
                    desc2TB.setEnabled(true);
                    desc3TB.setEnabled(true);
                    desc4TB.setEnabled(false);

                    perc1TB.setEnabled(true);
                    perc2TB.setEnabled(true);
                    perc3TB.setEnabled(true);
                    perc4TB.setEnabled(false);
                }
                if(checkedId==R.id.fourRB){
                    desc1TB.setEnabled(true);
                    desc2TB.setEnabled(true);
                    desc3TB.setEnabled(true);
                    desc4TB.setEnabled(true);

                    perc1TB.setEnabled(true);
                    perc2TB.setEnabled(true);
                    perc3TB.setEnabled(true);
                    perc4TB.setEnabled(true);
                }
            }
        });

        //Checks current descriptions
        loadSettings();

        //Sets Radio Button
        switch (boxMode) {
            case 1:
                oneRB.setChecked(true);
                break;
            case 2:
                twoRB.setChecked(true);
                break;
            case 3:
                threeRB.setChecked(true);
                break;
            case 4:
                fourRB.setChecked(true);
                break;
        }



        saveBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        return view;
    }

    /**
     * Loads the already saved settings into the textboxes and readio buttons
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void loadSettings() {
        //Reads settings from file to setup the page text boxes
        String settings = readFromFile();
        String[] individualSettings = settings.split(",");

        boxMode = Integer.parseInt(individualSettings[0]); //Sets how many boxes to saved settings
        desc1TB.setText(individualSettings[1]); //Sets description 1 Text to saved settings
        perc1TB.setText(individualSettings[2]); //Sets percentage 1 percentage amount
        desc2TB.setText(individualSettings[3]); //Sets description 2 Text to saved settings
        perc2TB.setText(individualSettings[4]); //Sets percentage 2 percentage amount
        desc3TB.setText(individualSettings[5]); //Sets description 3 Text to saved settings
        perc3TB.setText(individualSettings[6]); //Sets percentage 3 percentage amount
        desc4TB.setText(individualSettings[7]); //Sets description 4 Text to saved settings
        perc4TB.setText(individualSettings[8]); //Sets percentage 4 percentage amount

    }

    /**
     * Saves the settings to file saved_settings.txt
     */
    private void saveSettings() {
        checkRadioBtn();
        fillInEmpty();
        String settings = "" + boxMode + "," + desc1TB.getText() + "," + Double.parseDouble(perc1TB.getText().toString()) + "," + desc2TB.getText() + "," + Double.parseDouble(perc2TB.getText().toString()) + "," + desc3TB.getText() + "," + Double.parseDouble(perc3TB.getText().toString()) + "," + desc4TB.getText() + "," + Double.parseDouble(perc4TB.getText().toString());
        writeToFile(settings);
    }

    /**
     * Checks to see which radio button is checked
     */
    private void checkRadioBtn(){
        if (oneRB.isChecked()){
            boxMode = 1;
        }else if (twoRB.isChecked()){
            boxMode = 2;
        }else if (threeRB.isChecked()){
            boxMode = 3;
        }else{
            boxMode = 4;
        }
    }

    /**
     * If textbox is left empty, then fill in with 0
     */
    private void fillInEmpty(){
        if (perc1TB.getText().toString().length() < 1){
            perc1TB.setText("0");
        }
        if (perc2TB.getText().toString().length() < 1){
            perc2TB.setText("0");
        }
        if (perc3TB.getText().toString().length() < 1){
            perc3TB.setText("0");
        }
        if (perc4TB.getText().toString().length() < 1){
            perc4TB.setText("0");
        }
    }

    /**
     * Writes to file
     * @param text
     */
    private void writeToFile(String text) {
        FileOutputStream fos = null;
        Toast.makeText(getContext(), text,
                Toast.LENGTH_LONG).show();
        try {
            fos = getActivity().openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(text.getBytes());

            Toast.makeText(getContext(), "Saved to " + getContext().getFilesDir() + "/" + fileName,
                    Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Reads from file
     * @return
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private String readFromFile(){

        FileInputStream fis = null;
        try {
            fis = getContext().openFileInput(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(inputStreamReader)) {
            String line = reader.readLine();
            while (line != null) {
                stringBuilder.append(line).append('\n');
                line = reader.readLine();
            }
        } catch (IOException e) {
            // Error occurred when opening raw file for reading.
        } finally {
            String contents = stringBuilder.toString();
            return contents;
        }
    }

}
