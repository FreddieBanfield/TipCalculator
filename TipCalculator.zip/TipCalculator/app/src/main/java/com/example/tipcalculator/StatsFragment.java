package com.example.tipcalculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

public class StatsFragment  extends Fragment {

    private ListView recentStats;
    ArrayAdapter cashoutArrayAdapter;
    DataBaseHelper dataBaseHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_stats, container, false);
        recentStats = view.findViewById(R.id.recentStatsList);

        // loads in database
        dataBaseHelper = new DataBaseHelper(this.getContext());

        cashoutArrayAdapter = new ArrayAdapter<CashoutData>(this.getContext(), android.R.layout.simple_list_item_1, dataBaseHelper.getEveryDay());
        recentStats.setAdapter(cashoutArrayAdapter);

        //Toast.makeText(this.getContext(), allCashouts.toString(), Toast.LENGTH_SHORT).show();

        recentStats.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CashoutData clickedCashout = (CashoutData) parent.getItemAtPosition(position);
                dataBaseHelper.deleteOne(clickedCashout);
                cashoutArrayAdapter = new ArrayAdapter<CashoutData>(StatsFragment.this.getContext(), android.R.layout.simple_list_item_1, dataBaseHelper.getEveryDay());
                recentStats.setAdapter(cashoutArrayAdapter);
                Toast.makeText(StatsFragment.this.getContext(), "Deleted: " + clickedCashout.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        return view;
    }
}
